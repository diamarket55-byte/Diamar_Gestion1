
-- DiaMar Gestion V8 PRO
-- Catalogue public + commandes

ALTER TABLE public.products
  ADD COLUMN IF NOT EXISTS public_visible boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS photo_url text,
  ADD COLUMN IF NOT EXISTS description text;

CREATE TABLE IF NOT EXISTS public.orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  order_number text NOT NULL,
  customer_name text,
  phone text,
  status text NOT NULL DEFAULT 'NOUVELLE',
  total_amount numeric NOT NULL DEFAULT 0,
  paid_amount numeric NOT NULL DEFAULT 0,
  note text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "orders_user_policy" ON public.orders;
CREATE POLICY "orders_user_policy" ON public.orders
FOR ALL TO authenticated
USING ((select auth.uid()) = user_id)
WITH CHECK ((select auth.uid()) = user_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.orders TO authenticated;

CREATE INDEX IF NOT EXISTS orders_user_created_idx
ON public.orders(user_id, created_at DESC);

NOTIFY pgrst, 'reload schema';
