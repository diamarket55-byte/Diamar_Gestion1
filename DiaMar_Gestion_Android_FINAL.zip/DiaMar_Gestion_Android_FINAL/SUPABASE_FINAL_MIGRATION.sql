
-- DiaMar Gestion FINAL
-- Durcissement léger du schéma + vue de synthèse.

CREATE UNIQUE INDEX IF NOT EXISTS orders_user_order_number_uq
ON public.orders(user_id, order_number);

CREATE INDEX IF NOT EXISTS sales_user_date_idx
ON public.sales(user_id, created_at DESC);

CREATE INDEX IF NOT EXISTS purchases_user_date_idx
ON public.purchases(user_id, created_at DESC);

CREATE INDEX IF NOT EXISTS expenses_user_date_idx
ON public.expenses(user_id, created_at DESC);

-- Vue de synthèse du stock, accessible seulement via les données RLS des tables sources.
CREATE OR REPLACE VIEW public.diamar_stock_summary AS
SELECT
  p.id,
  p.user_id,
  p.name,
  p.category,
  p.purchase_price,
  p.sale_price,
  p.stock,
  p.min_stock,
  p.archived,
  CASE
    WHEN p.stock <= p.min_stock THEN true
    ELSE false
  END AS low_stock
FROM public.products p;

NOTIFY pgrst, 'reload schema';
