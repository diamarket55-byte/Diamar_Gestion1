
-- DiaMar Gestion V9 PRO
-- Cycle de vie des commandes et préparation du suivi.

ALTER TABLE public.orders
  ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

ALTER TABLE public.orders
  ALTER COLUMN status SET DEFAULT 'NOUVELLE';

CREATE INDEX IF NOT EXISTS orders_status_idx
ON public.orders(user_id, status, created_at DESC);

CREATE INDEX IF NOT EXISTS orders_phone_idx
ON public.orders(user_id, phone);

-- Valeurs prévues :
-- NOUVELLE / CONFIRMEE / PREPAREE / LIVREE / ANNULEE

CREATE OR REPLACE FUNCTION public.set_orders_updated_at()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS orders_updated_at ON public.orders;
CREATE TRIGGER orders_updated_at
BEFORE UPDATE ON public.orders
FOR EACH ROW EXECUTE FUNCTION public.set_orders_updated_at();

NOTIFY pgrst, 'reload schema';
