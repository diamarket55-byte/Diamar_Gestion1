package com.diamarket.gestion

import android.os.Bundle
import android.content.Intent
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.auth.Auth
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.auth.providers.builtin.Email
import io.github.jan.supabase.postgrest.Postgrest
import kotlinx.coroutines.launch
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val SUPABASE_URL = "https://ykjfzturarksfbkcgnvc.supabase.co"
private const val SUPABASE_KEY = "sb_publishable_BonrJcWteOS8jnBr_lzRaQ_jOTqTRXv"

val supabase = createSupabaseClient(SUPABASE_URL, SUPABASE_KEY) {
    install(Postgrest)
    install(Auth)
}

private fun money(v: Double) = "${v.toLong()} F"
private fun num(v: String) = v.replace(",", ".").toDoubleOrNull() ?: 0.0
private fun nowTag() = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())

@Serializable
data class Product(
    val id: String,
    val name: String,
    val category: String? = null,
    @SerialName("purchase_price") val purchasePrice: Double = 0.0,
    @SerialName("sale_price") val salePrice: Double = 0.0,
    val stock: Double = 0.0,
    @SerialName("min_stock") val minStock: Double = 0.0,
    val archived: Boolean = false
)

@Serializable
data class Sale(
    val id: String,
    @SerialName("invoice_number") val invoice: String? = null,
    @SerialName("client_name") val client: String? = null,
    @SerialName("payment_method") val paymentMethod: String? = null,
    @SerialName("total_amount") val total: Double = 0.0,
    @SerialName("paid_amount") val paid: Double = 0.0,
    @SerialName("cost_amount") val cost: Double = 0.0,
    val quantity: Double = 0.0
)

@Serializable
data class Purchase(
    val id: String,
    @SerialName("purchase_number") val number: String? = null,
    @SerialName("invoice_number") val invoice: String? = null,
    @SerialName("supplier_name") val supplier: String? = null,
    @SerialName("cargo_amount") val cargo: Double = 0.0,
    @SerialName("total_amount") val total: Double = 0.0,
    @SerialName("paid_amount") val paid: Double = 0.0,
    val quantity: Double = 0.0
)

@Serializable
data class Expense(
    val id: String,
    val description: String? = null,
    val amount: Double = 0.0,
    @SerialName("payment_method") val paymentMethod: String? = null
)


@Serializable
data class CatalogOrder(
    val id: String,
    @SerialName("order_number") val orderNumber: String? = null,
    @SerialName("customer_name") val customerName: String? = null,
    val phone: String? = null,
    val status: String? = null,
    @SerialName("total_amount") val total: Double = 0.0,
    @SerialName("paid_amount") val paid: Double = 0.0,
    val note: String? = null
)

@Serializable
data class StockMovement(
    val id: String,
    @SerialName("product_id") val productId: String? = null,
    val type: String? = null,
    val quantity: Double = 0.0,
    val reason: String? = null
)

@Serializable
data class ClientPayment(
    val id: String,
    @SerialName("client_name") val clientName: String? = null,
    val amount: Double = 0.0,
    val note: String? = null
)

@Serializable
data class Client(val id: String, val name: String, val phone: String? = null, val type: String? = null)
@Serializable
data class Supplier(val id: String, val name: String, val phone: String? = null, val type: String? = null)


private fun buildInvoicePdf(
    activity: ComponentActivity,
    title: String,
    invoice: String,
    client: String,
    lines: List<Pair<String, String>>,
    total: Double,
    paid: Double
): Uri? {
    return try {
        val doc = PdfDocument()
        val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
        val c = page.canvas
        val paint = Paint().apply { textSize = 18f; isFakeBoldText = true }
        c.drawText("DiaMar Gestion", 40f, 55f, paint)
        paint.textSize = 13f; paint.isFakeBoldText = false
        c.drawText(title, 40f, 82f, paint)
        c.drawText("Facture: $invoice", 40f, 110f, paint)
        c.drawText("Client: ${client.ifBlank { "Client sans nom" }}", 40f, 132f, paint)
        var y = 175f
        lines.forEach {
            c.drawText("${it.first} : ${it.second}", 40f, y, paint)
            y += 24f
        }
        paint.isFakeBoldText = true
        c.drawText("TOTAL : ${money(total)}", 40f, y + 20f, paint)
        paint.isFakeBoldText = false
        c.drawText("PAYE : ${money(paid)}", 40f, y + 44f, paint)
        c.drawText("RESTE : ${money((total - paid).coerceAtLeast(0.0))}", 40f, y + 68f, paint)
        doc.finishPage(page)
        val file = File(activity.cacheDir, "DiaMar_$invoice.pdf")
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        FileProvider.getUriForFile(activity, "${activity.packageName}.provider", file)
    } catch (_: Exception) { null }
}

private fun sharePdf(activity: ComponentActivity, uri: Uri) {
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "application/pdf"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    activity.startActivity(Intent.createChooser(intent, "Partager la facture"))
}

class MainActivity : ComponentActivity() {
    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        setContent { DiaMarApp() }
    }
}

@Composable
fun DiaMarApp() {
    var logged by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { logged = supabase.auth.currentSessionOrNull() != null }
    if (logged) MainShell(onLogout = {
        kotlinx.coroutines.MainScope().launch { supabase.auth.signOut(); logged = false }
    }) else LoginScreen { logged = true }
}

@Composable
fun LoginScreen(onLogin: () -> Unit) {
    val scope = rememberCoroutineScope()
    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    Surface(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().padding(24.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.Center
        ) {
            Text("DiaMar Gestion", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
            Text("Gestion commerciale moderne", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(28.dp))
            OutlinedTextField(email, { email = it }, Modifier.fillMaxWidth(), label = { Text("E-mail") })
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(pass, { pass = it }, Modifier.fillMaxWidth(), label = { Text("Mot de passe") })
            Spacer(Modifier.height(16.dp))
            Button(
                enabled = !loading && email.isNotBlank() && pass.isNotBlank(),
                onClick = {
                    scope.launch {
                        loading = true; error = ""
                        try {
                            supabase.auth.signInWith(Email) { this.email = email.trim(); password = pass }
                            onLogin()
                        } catch (e: Exception) { error = e.message ?: "Connexion impossible" }
                        loading = false
                    }
                },
                Modifier.fillMaxWidth()
            ) { Text(if (loading) "Connexion..." else "Se connecter") }
            if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
        }
    }
}

enum class Screen { DASHBOARD, SALES, STOCK, CREDIT, PURCHASES, EXPENSES, CONTACTS, REPORTS, MOVEMENTS, CATALOG }

@Composable
fun MainShell(onLogout: () -> Unit) {
    var screen by remember { mutableStateOf(Screen.DASHBOARD) }
    var refresh by remember { mutableIntStateOf(0) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("DiaMar Gestion", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton({ refresh++ }) { Icon(Icons.Default.Refresh, "Actualiser") }
                    IconButton(onLogout) { Icon(Icons.Default.Logout, "Déconnexion") }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                listOf(
                    Screen.DASHBOARD to ("Accueil" to Icons.Default.Home),
                    Screen.SALES to ("Vente" to Icons.Default.PointOfSale),
                    Screen.STOCK to ("Stock" to Icons.Default.Inventory),
                    Screen.CREDIT to ("Crédits" to Icons.Default.CreditCard),
                    Screen.PURCHASES to ("Achats" to Icons.Default.ShoppingCart),
                    Screen.CATALOG to ("Catalogue" to Icons.Default.Storefront),
                    Screen.REPORTS to ("Rapports" to Icons.Default.Assessment)
                ).forEach { (s, pair) ->
                    NavigationBarItem(
                        selected = screen == s,
                        onClick = { screen = s },
                        icon = { Icon(pair.second, null) },
                        label = { Text(pair.first) }
                    )
                }
            }
        }
    ) { pad ->
        when (screen) {
            Screen.DASHBOARD -> DashboardScreen(Modifier.padding(pad), refresh, { screen = Screen.SALES })
            Screen.SALES -> SalesScreen(Modifier.padding(pad), refresh) { refresh++ }
            Screen.STOCK -> StockScreen(Modifier.padding(pad), refresh) { refresh++ }
            Screen.CREDIT -> CreditScreen(Modifier.padding(pad), refresh) { refresh++ }
            Screen.PURCHASES -> PurchaseScreen(Modifier.padding(pad), refresh) { refresh++ }
            Screen.EXPENSES -> ExpenseScreen(Modifier.padding(pad), refresh) { refresh++ }
            Screen.CONTACTS -> ContactsScreen(Modifier.padding(pad), refresh)
            Screen.REPORTS -> ReportsScreen(Modifier.padding(pad), refresh)
            Screen.MOVEMENTS -> MovementsScreen(Modifier.padding(pad), refresh)
            Screen.CATALOG -> CatalogScreen(Modifier.padding(pad), refresh)
        }
    }
}

@Composable
fun DashboardScreen(mod: Modifier, refresh: Int, goSale: () -> Unit) {
    val scope = rememberCoroutineScope()
    var sales by remember { mutableStateOf<List<Sale>>(emptyList()) }
    var purchases by remember { mutableStateOf<List<Purchase>>(emptyList()) }
    var products by remember { mutableStateOf<List<Product>>(emptyList()) }
    var expenses by remember { mutableStateOf<List<Expense>>(emptyList()) }
    var error by remember { mutableStateOf("") }

    LaunchedEffect(refresh) {
        try {
            sales = supabase.from("sales").select().decodeList()
            purchases = supabase.from("purchases").select().decodeList()
            products = supabase.from("products").select().decodeList<Product>().filter { !it.archived }
            expenses = supabase.from("expenses").select().decodeList()
        } catch (e: Exception) { error = e.message ?: "Erreur" }
    }
    val ca = sales.sumOf { it.total }
    val profit = sales.sumOf { it.total - it.cost } - expenses.sumOf { it.amount }
    val receivable = sales.sumOf { (it.total - it.paid).coerceAtLeast(0.0) }
    val payable = purchases.sumOf { (it.total - it.paid).coerceAtLeast(0.0) }
    val alerts = products.count { it.stock <= it.minStock }

    Column(mod.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
        Text("Tableau de bord", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricCard("CA", money(ca), Modifier.weight(1f))
            MetricCard("Résultat", money(profit), Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricCard("À recevoir", money(receivable), Modifier.weight(1f))
            MetricCard("À payer", money(payable), Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))
        Text("Stock : ${products.size} produit(s) • $alerts alerte(s)", fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Button(goSale, Modifier.fillMaxWidth()) { Text("⚡ Nouvelle vente") }
        OutlinedButton({ /* navigation via bottom */ }, Modifier.fillMaxWidth()) { Text("CA total : ${money(ca)}") }
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton({ /* hidden navigation */ }, Modifier.weight(1f)) { Text("📊 Rapports") }
            OutlinedButton({ /* hidden navigation */ }, Modifier.weight(1f)) { Text("📦 Mouvements") }
        }
        Spacer(Modifier.height(8.dp))
        Text("Raccourcis", fontWeight = FontWeight.Bold)
        Text("• Vente : caisse, crédit, paiement partiel")
        Text("• Achats : stock, fournisseur, cargo, dette")
        Text("• Crédits : clients nommés et ventes anonymes")
        Text("• Rapports : CA, marge, dépenses et dettes")
        Text("• Catalogue : produits visibles, prix et commandes WhatsApp")
    }
}

@Composable
fun MetricCard(title: String, value: String, mod: Modifier) {
    Card(mod.padding(vertical = 4.dp)) {
        Column(Modifier.padding(14.dp)) {
            Text(title, style = MaterialTheme.typography.labelLarge)
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun SalesScreen(mod: Modifier, refresh: Int, onSaved: () -> Unit) {
    val activity = androidx.compose.ui.platform.LocalContext.current as ComponentActivity
    val scope = rememberCoroutineScope()
    var products by remember { mutableStateOf<List<Product>>(emptyList()) }
    var product by remember { mutableStateOf<Product?>(null) }
    var qty by remember { mutableStateOf("1") }
    var client by remember { mutableStateOf("") }
    var method by remember { mutableStateOf("Espèces") }
    var paid by remember { mutableStateOf("") }
    var customPrice by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    var ok by remember { mutableStateOf("") }
    var lastInvoice by remember { mutableStateOf<String?>(null) }
    var lastTotal by remember { mutableDoubleStateOf(0.0) }
    var lastPaid by remember { mutableDoubleStateOf(0.0) }

    LaunchedEffect(refresh) {
        try { products = supabase.from("products").select().decodeList<Product>().filter { !it.archived && it.stock > 0 } }
        catch (e: Exception) { error = e.message ?: "Erreur" }
    }
    val q = num(qty)
    val price = if (customPrice.isBlank()) product?.salePrice ?: 0.0 else num(customPrice)
    val total = price * q
    val p = num(paid)
    val reste = (total - p).coerceAtLeast(0.0)

    Column(mod.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
        Text("Caisse / Nouvelle vente", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        ProductPicker(products, product) { product = it; customPrice = "" }
        OutlinedTextField(qty, { qty = it }, Modifier.fillMaxWidth(), label = { Text("Quantité") })
        OutlinedTextField(customPrice, { customPrice = it }, Modifier.fillMaxWidth(), label = { Text("Prix de vente personnalisé (facultatif)") })
        OutlinedTextField(client, { client = it }, Modifier.fillMaxWidth(), label = { Text("Client (facultatif)") })
        OutlinedTextField(method, { method = it }, Modifier.fillMaxWidth(), label = { Text("Paiement") })
        OutlinedTextField(paid, { paid = it }, Modifier.fillMaxWidth(), label = { Text("Montant payé") })
        Spacer(Modifier.height(8.dp))
        Text("Prix unitaire : ${money(price)}")
        Text("Total : ${money(total)}", fontWeight = FontWeight.Bold)
        Text("Reste : ${money(reste)}")
        Button(
            enabled = product != null && q > 0 && q <= (product?.stock ?: 0.0) && total > 0,
            onClick = {
                scope.launch {
                    try {
                        val pr = product!!
                        val invoice = "V-${nowTag()}"
                        val paidSafe = p.coerceIn(0.0, total)
                        val body = buildJsonObject {
                            put("user_id", supabase.auth.currentUserOrNull()?.id)
                            put("invoice_number", invoice)
                            put("client_name", client.ifBlank { null })
                            put("payment_method", method)
                            put("total_amount", total)
                            put("paid_amount", paidSafe)
                            put("cost_amount", pr.purchasePrice * q)
                            put("quantity", q)
                        }
                        val inserted = supabase.from("sales").insert(body) { select() }.decodeSingle<Sale>()
                        supabase.from("sale_items").insert(buildJsonObject {
                            put("user_id", supabase.auth.currentUserOrNull()?.id)
                            put("sale_id", inserted.id)
                            put("product_id", pr.id)
                            put("quantity", q)
                            put("unit_price", price)
                            put("total", total)
                        })
                        supabase.from("products").update(buildJsonObject { put("stock", pr.stock - q) }) { filter { eq("id", pr.id) } }
                        lastInvoice = invoice; lastTotal = total; lastPaid = paidSafe
                        ok = "Vente $invoice enregistrée"
                        product = null; qty = "1"; client = ""; paid = ""; customPrice = ""
                        onSaved()
                    } catch (e: Exception) { error = e.message ?: "Erreur lors de la vente" }
                }
            },
            Modifier.fillMaxWidth()
        ) { Text("Enregistrer la vente") }

        if (lastInvoice != null) {
            Spacer(Modifier.height(8.dp))
            OutlinedButton({
                val uri = buildInvoicePdf(activity, "Ticket de vente", lastInvoice!!, client, emptyList(), lastTotal, lastPaid)
                if (uri != null) sharePdf(activity, uri)
            }, Modifier.fillMaxWidth()) { Text("📄 Partager la facture PDF") }
            OutlinedButton({
                val text = "DiaMar Gestion — Vente $lastInvoice\nTotal: ${money(lastTotal)}\nPayé: ${money(lastPaid)}\nReste: ${money((lastTotal-lastPaid).coerceAtLeast(0.0))}"
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text)
                }
                activity.startActivity(Intent.createChooser(intent, "Partager la vente"))
            }, Modifier.fillMaxWidth()) { Text("💬 Partager le résumé / WhatsApp") }
        }
        if (ok.isNotBlank()) Text(ok, color = MaterialTheme.colorScheme.primary)
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
    }
}

@Composable
fun ProductPicker(products: List<Product>, selected: Product?, onPick: (Product) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Column {
        Box {
            OutlinedButton({ expanded = true }, Modifier.fillMaxWidth()) {
                Text(selected?.name ?: "Choisir un produit")
            }
            DropdownMenu(expanded, { expanded = false }) {
                products.forEach { p ->
                    DropdownMenuItem(
                        text = { Text("${p.name} • stock ${p.stock.toLong()} • ${money(p.salePrice)}") },
                        onClick = { onPick(p); expanded = false }
                    )
                }
            }
        }
    }
}

@Composable
fun StockScreen(mod: Modifier, refresh: Int, onSaved: () -> Unit) {
    val scope = rememberCoroutineScope()
    var products by remember { mutableStateOf<List<Product>>(emptyList()) }
    var dialog by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf("") }
    var buy by remember { mutableStateOf("") }
    var sell by remember { mutableStateOf("") }
    var stock by remember { mutableStateOf("") }
    var min by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }

    fun load() = scope.launch {
        try { products = supabase.from("products").select().decodeList<Product>().filter { !it.archived } }
        catch (e: Exception) { error = e.message ?: "Erreur" }
    }
    LaunchedEffect(refresh) { load() }

    Column(mod.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Stock", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Button({ dialog = true }) { Text("+ Produit") }
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(products) { p ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp)) {
                        Text(p.name, fontWeight = FontWeight.Bold)
                        Text("${p.category ?: "Sans catégorie"} • achat ${money(p.purchasePrice)} • vente ${money(p.salePrice)}")
                        Text("Stock : ${p.stock.toLong()} • seuil : ${p.minStock.toLong()}",
                            color = if (p.stock <= p.minStock) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton({
                                scope.launch {
                                    try {
                                        supabase.from("products").update(buildJsonObject { put("archived", true) }) { filter { eq("id", p.id) } }
                                        load(); onSaved()
                                    } catch (e: Exception) { error = e.message ?: "Erreur" }
                                }
                            }) { Text("Archiver") }
                        }
                    }
                }
            }
        }
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
    }

    if (dialog) AlertDialog(
        onDismissRequest = { dialog = false },
        title = { Text("Nouveau produit") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(name, { name = it }, label = { Text("Nom") })
                OutlinedTextField(cat, { cat = it }, label = { Text("Catégorie") })
                OutlinedTextField(buy, { buy = it }, label = { Text("Prix achat") })
                OutlinedTextField(sell, { sell = it }, label = { Text("Prix vente") })
                OutlinedTextField(stock, { stock = it }, label = { Text("Stock initial") })
                OutlinedTextField(min, { min = it }, label = { Text("Stock minimum") })
            }
        },
        confirmButton = {
            Button({
                scope.launch {
                    try {
                        supabase.from("products").insert(buildJsonObject {
                            put("user_id", supabase.auth.currentUserOrNull()?.id)
                            put("name", name); put("category", cat.ifBlank { null })
                            put("purchase_price", num(buy)); put("sale_price", num(sell))
                            put("stock", num(stock)); put("min_stock", num(min))
                            put("archived", false)
                        })
                        dialog = false; name = ""; cat = ""; buy = ""; sell = ""; stock = ""; min = ""; load(); onSaved()
                    } catch (e: Exception) { error = e.message ?: "Erreur" }
                }
            }) { Text("Créer") }
        },
        dismissButton = { TextButton({ dialog = false }) { Text("Annuler") } }
    )
}

@Composable
fun CreditScreen(mod: Modifier, refresh: Int, onSaved: () -> Unit) {
    val scope = rememberCoroutineScope()
    var sales by remember { mutableStateOf<List<Sale>>(emptyList()) }
    var selected by remember { mutableStateOf<Sale?>(null) }
    var amount by remember { mutableStateOf("") }
    var info by remember { mutableStateOf("") }

    fun load() = scope.launch {
        try { sales = supabase.from("sales").select().decodeList<Sale>().filter { it.total > it.paid } }
        catch (e: Exception) { info = e.message ?: "Erreur" }
    }
    LaunchedEffect(refresh) { load() }

    Column(mod.fillMaxSize().padding(16.dp)) {
        Text("Crédits & paiements", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("${sales.size} vente(s) avec reste à payer")
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(sales) { sale ->
                val rest = sale.total - sale.paid
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp)) {
                        Text(sale.invoice ?: "Vente", fontWeight = FontWeight.Bold)
                        Text(sale.client?.ifBlank { "Client sans nom" } ?: "Client sans nom")
                        Text("Total ${money(sale.total)} • payé ${money(sale.paid)}")
                        Text("Reste ${money(rest)}", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                        Button({ selected = sale; amount = "" }) { Text("＋ Paiement") }
                    }
                }
            }
        }
        if (info.isNotBlank()) Text(info, color = MaterialTheme.colorScheme.error)
    }
    selected?.let { sale ->
        val rest = sale.total - sale.paid
        AlertDialog(
            onDismissRequest = { selected = null },
            title = { Text("Paiement") },
            text = { OutlinedTextField(amount, { amount = it }, label = { Text("Montant reçu (reste ${money(rest)})") }) },
            confirmButton = {
                Button({
                    val a = num(amount)
                    if (a <= 0 || a > rest) { info = "Montant invalide"; return@Button }
                    scope.launch {
                        try {
                            val newPaid = sale.paid + a
                            supabase.from("sales").update(buildJsonObject { put("paid_amount", newPaid) }) { filter { eq("id", sale.id) } }
                            supabase.from("client_payments").insert(buildJsonObject {
                                put("user_id", supabase.auth.currentUserOrNull()?.id)
                                put("client_name", sale.client ?: "Client sans nom")
                                put("amount", a)
                                put("note", "Paiement ${sale.invoice ?: sale.id}")
                            })
                            selected = null; info = "Paiement enregistré"; load(); onSaved()
                        } catch (e: Exception) { info = e.message ?: "Erreur" }
                    }
                }) { Text("Valider") }
            },
            dismissButton = { TextButton({ selected = null }) { Text("Annuler") } }
        )
    }
}

@Composable
fun PurchaseScreen(mod: Modifier, refresh: Int, onSaved: () -> Unit) {
    val scope = rememberCoroutineScope()
    var products by remember { mutableStateOf<List<Product>>(emptyList()) }
    var product by remember { mutableStateOf<Product?>(null) }
    var supplier by remember { mutableStateOf("") }
    var invoice by remember { mutableStateOf("") }
    var qty by remember { mutableStateOf("1") }
    var unit by remember { mutableStateOf("") }
    var cargo by remember { mutableStateOf("0") }
    var paid by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    var ok by remember { mutableStateOf("") }

    LaunchedEffect(refresh) {
        try { products = supabase.from("products").select().decodeList<Product>().filter { !it.archived } }
        catch (e: Exception) { error = e.message ?: "Erreur" }
    }
    val q = num(qty); val u = num(unit); val c = num(cargo); val total = q * u + c
    Column(mod.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
        Text("Nouvel achat / Approvisionnement", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        ProductPicker(products, product) { product = it; if (unit.isBlank()) unit = it.purchasePrice.toString() }
        OutlinedTextField(supplier, { supplier = it }, Modifier.fillMaxWidth(), label = { Text("Fournisseur") })
        OutlinedTextField(invoice, { invoice = it }, Modifier.fillMaxWidth(), label = { Text("Facture fournisseur") })
        OutlinedTextField(qty, { qty = it }, Modifier.fillMaxWidth(), label = { Text("Quantité") })
        OutlinedTextField(unit, { unit = it }, Modifier.fillMaxWidth(), label = { Text("Prix unitaire") })
        OutlinedTextField(cargo, { cargo = it }, Modifier.fillMaxWidth(), label = { Text("Cargo / transport") })
        OutlinedTextField(paid, { paid = it }, Modifier.fillMaxWidth(), label = { Text("Montant payé") })
        Text("Total : ${money(total)}", fontWeight = FontWeight.Bold)
        Text("Reste : ${money((total - num(paid)).coerceAtLeast(0.0))}")
        Button(
            enabled = product != null && q > 0 && u > 0,
            onClick = {
                scope.launch {
                    try {
                        val pr = product!!
                        val purchaseNo = "ACH-${nowTag()}"
                        val body = buildJsonObject {
                            put("user_id", supabase.auth.currentUserOrNull()?.id)
                            put("purchase_number", purchaseNo)
                            put("invoice_number", invoice.ifBlank { null })
                            put("supplier_name", supplier.ifBlank { null })
                            put("cargo_amount", c)
                            put("total_amount", total)
                            put("paid_amount", num(paid).coerceIn(0.0, total))
                            put("quantity", q)
                        }
                        val ins = supabase.from("purchases").insert(body) { select() }.decodeSingle<Purchase>()
                        supabase.from("purchase_items").insert(buildJsonObject {
                            put("user_id", supabase.auth.currentUserOrNull()?.id)
                            put("purchase_id", ins.id); put("product_id", pr.id)
                            put("quantity", q); put("unit_price", u); put("total", q*u)
                        })
                        supabase.from("products").update(buildJsonObject {
                            put("stock", pr.stock + q); put("purchase_price", u)
                        }) { filter { eq("id", pr.id) } }
                        ok = "Achat $purchaseNo enregistré"
                        product = null; supplier = ""; invoice = ""; qty = "1"; unit = ""; cargo = "0"; paid = ""
                        onSaved()
                    } catch (e: Exception) { error = e.message ?: "Erreur" }
                }
            },
            Modifier.fillMaxWidth()
        ) { Text("Enregistrer l'achat") }
        if (ok.isNotBlank()) Text(ok, color = MaterialTheme.colorScheme.primary)
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
    }
}

@Composable
fun ExpenseScreen(mod: Modifier, refresh: Int, onSaved: () -> Unit) {
    val scope = rememberCoroutineScope()
    var expenses by remember { mutableStateOf<List<Expense>>(emptyList()) }
    var desc by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var method by remember { mutableStateOf("Espèces") }
    var error by remember { mutableStateOf("") }

    fun load() = scope.launch {
        try { expenses = supabase.from("expenses").select().decodeList() }
        catch (e: Exception) { error = e.message ?: "Erreur" }
    }
    LaunchedEffect(refresh) { load() }

    Column(mod.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
        Text("Dépenses", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        OutlinedTextField(desc, { desc = it }, Modifier.fillMaxWidth(), label = { Text("Description") })
        OutlinedTextField(amount, { amount = it }, Modifier.fillMaxWidth(), label = { Text("Montant") })
        OutlinedTextField(method, { method = it }, Modifier.fillMaxWidth(), label = { Text("Paiement") })
        Button({
            scope.launch {
                try {
                    supabase.from("expenses").insert(buildJsonObject {
                        put("user_id", supabase.auth.currentUserOrNull()?.id)
                        put("description", desc); put("amount", num(amount)); put("payment_method", method)
                    })
                    desc = ""; amount = ""; load(); onSaved()
                } catch (e: Exception) { error = e.message ?: "Erreur" }
            }
        }, Modifier.fillMaxWidth()) { Text("Ajouter la dépense") }
        Spacer(Modifier.height(10.dp))
        expenses.forEach { e ->
            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(e.description ?: "Dépense")
                    Text(money(e.amount), fontWeight = FontWeight.Bold)
                }
            }
        }
        if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
    }
}

@Composable
fun ContactsScreen(mod: Modifier, refresh: Int) {
    val scope = rememberCoroutineScope()
    var clients by remember { mutableStateOf<List<Client>>(emptyList()) }
    var suppliers by remember { mutableStateOf<List<Supplier>>(emptyList()) }
    LaunchedEffect(refresh) {
        try {
            clients = supabase.from("clients").select().decodeList()
            suppliers = supabase.from("suppliers").select().decodeList()
        } catch (_: Exception) {}
    }
    Column(mod.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
        Text("Clients & fournisseurs", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Clients : ${clients.size}")
        clients.forEach { Text("• ${it.name}${it.phone?.let { p -> " — $p" } ?: ""}") }
        Spacer(Modifier.height(12.dp))
        Text("Fournisseurs : ${suppliers.size}")
        suppliers.forEach { Text("• ${it.name}${it.phone?.let { p -> " — $p" } ?: ""}") }
    }
}

@Composable
fun ReportsScreen(mod: Modifier, refresh: Int) {
    val activity = androidx.compose.ui.platform.LocalContext.current as ComponentActivity
    var sales by remember { mutableStateOf<List<Sale>>(emptyList()) }
    var purchases by remember { mutableStateOf<List<Purchase>>(emptyList()) }
    var expenses by remember { mutableStateOf<List<Expense>>(emptyList()) }
    LaunchedEffect(refresh) {
        try {
            sales = supabase.from("sales").select().decodeList()
            purchases = supabase.from("purchases").select().decodeList()
            expenses = supabase.from("expenses").select().decodeList()
        } catch (_: Exception) {}
    }
    val ca = sales.sumOf { it.total }
    val cout = sales.sumOf { it.cost }
    val dep = expenses.sumOf { it.amount }
    val creances = sales.sumOf { (it.total - it.paid).coerceAtLeast(0.0) }
    val dettes = purchases.sumOf { (it.total - it.paid).coerceAtLeast(0.0) }

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
        Text("Rapports", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        ReportLine("Chiffre d'affaires", ca)
        ReportLine("Coût des marchandises vendues", cout)
        ReportLine("Dépenses", dep)
        ReportLine("Marge brute", ca - cout)
        ReportLine("Résultat après dépenses", ca - cout - dep)
        ReportLine("Créances clients", creances)
        ReportLine("Dettes fournisseurs", dettes)
        Spacer(Modifier.height(8.dp))
        Button({
            val text = """
                DiaMar Gestion — Rapport
                CA : ${money(ca)}
                Coût marchandises : ${money(cout)}
                Dépenses : ${money(dep)}
                Marge brute : ${money(ca-cout)}
                Résultat : ${money(ca-cout-dep)}
                Créances : ${money(creances)}
                Dettes fournisseurs : ${money(dettes)}
            """.trimIndent()
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text)
            }
            activity.startActivity(Intent.createChooser(intent, "Partager le rapport"))
        }, Modifier.fillMaxWidth()) { Text("📤 Partager le rapport") }
    }
}




private suspend fun updateOrderStatus(orderId: String, status: String) {
    supabase.from("orders").update({
        put("status", status)
    }) {
        filter { eq("id", orderId) }
    }
}


private suspend fun exportProductsCsv(context: android.content.Context) {
    val rows = supabase.from("products").select().decodeList<Product>()
    val csv = buildString {
        append("Nom;Categorie;Prix achat;Prix vente;Stock;Stock minimum\n")
        rows.forEach {
            append("${it.name};${it.category ?: ""};${it.purchasePrice};${it.salePrice};${it.stock};${it.minStock}\n")
        }
    }
    val file = java.io.File(context.cacheDir, "diamar_produits.csv")
    file.writeText(csv, Charsets.UTF_8)
    val uri = androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/csv"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, "Exporter les produits"))
}

@Composable
fun CatalogScreen(mod: Modifier, refresh: Int) {
    val activity = androidx.compose.ui.platform.LocalContext.current as ComponentActivity
    val scope = rememberCoroutineScope()
    var products by remember { mutableStateOf<List<Product>>(emptyList()) }
    var orders by remember { mutableStateOf<List<CatalogOrder>>(emptyList()) }
    var customer by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<Product?>(null) }
    var qty by remember { mutableStateOf("1") }
    var message by remember { mutableStateOf("") }

    fun load() = scope.launch {
        try {
            products = supabase.from("products").select().decodeList<Product>()
                .filter { !it.archived }
            orders = supabase.from("orders").select().decodeList<CatalogOrder>()
        } catch (e: Exception) { message = e.message ?: "Erreur catalogue" }
    }
    LaunchedEffect(refresh) { load() }

    val q = num(qty)
    val total = (selected?.salePrice ?: 0.0) * q

    Column(mod.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
        Text("Catalogue & commandes", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        val context = androidx.compose.ui.platform.LocalContext.current
        OutlinedButton({ scope.launch { try { exportProductsCsv(context) } catch (e: Exception) { message = e.message ?: "Export impossible" } } }, Modifier.fillMaxWidth()) {
            Text("Exporter les produits (CSV)")
        }
        Text("Prépare les produits à partager et les commandes reçues.")
        Spacer(Modifier.height(8.dp))
        ProductPicker(products, selected) { selected = it }
        OutlinedTextField(qty, { qty = it }, Modifier.fillMaxWidth(), label = { Text("Quantité") })
        OutlinedTextField(customer, { customer = it }, Modifier.fillMaxWidth(), label = { Text("Nom client") })
        OutlinedTextField(phone, { phone = it }, Modifier.fillMaxWidth(), label = { Text("Téléphone WhatsApp") })
        OutlinedTextField(note, { note = it }, Modifier.fillMaxWidth(), label = { Text("Note / livraison") })
        Text("Total estimé : ${money(total)}", fontWeight = FontWeight.Bold)

        Button({
            val p = selected
            if (p == null || q <= 0) { message = "Choisis un produit et une quantité"; return@Button }
            val text = "Bonjour, je souhaite commander chez DiaMar Gestion :\n${p.name}\nQuantité : ${q.toLong()}\nPrix : ${money(total)}\nClient : ${customer.ifBlank { "Non précisé" }}\nTéléphone : ${phone.ifBlank { "Non précisé" }}\nNote : ${note.ifBlank { "Aucune" }}"
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
            }
            activity.startActivity(Intent.createChooser(intent, "Envoyer la commande"))
        }, Modifier.fillMaxWidth()) { Text("💬 Envoyer la commande par WhatsApp") }

        Button({
            val p = selected
            if (p == null || q <= 0) { message = "Choisis un produit et une quantité"; return@Button }
            scope.launch {
                try {
                    supabase.from("orders").insert(buildJsonObject {
                        put("user_id", supabase.auth.currentUserOrNull()?.id)
                        put("order_number", "CMD-${nowTag()}")
                        put("customer_name", customer.ifBlank { null })
                        put("phone", phone.ifBlank { null })
                        put("status", "NOUVELLE")
                        put("total_amount", total)
                        put("paid_amount", 0)
                        put("note", note.ifBlank { null })
                    })
                    message = "Commande enregistrée"
                    customer = ""; phone = ""; note = ""; qty = "1"; selected = null
                    load()
                } catch (e: Exception) { message = e.message ?: "La table orders n'est pas encore prête" }
            }
        }, Modifier.fillMaxWidth()) { Text("Enregistrer la commande") }

        if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(16.dp))
        Text("Commandes récentes : ${orders.size}", fontWeight = FontWeight.Bold)
        orders.takeLast(20).reversed().forEach { o ->
            var busy by remember(o.id) { mutableStateOf(false) }
            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Text(o.orderNumber ?: "Commande", fontWeight = FontWeight.Bold)
                    Text("${o.customerName ?: "Client"} • ${o.phone ?: ""}")
                    Text("${money(o.total)} • ${o.status ?: "NOUVELLE"}", fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("CONFIRMEE", "PREPAREE", "LIVREE", "ANNULEE").forEach { st ->
                            OutlinedButton(
                                enabled = !busy,
                                onClick = {
                                    scope.launch {
                                        busy = true
                                        try {
                                            updateOrderStatus(o.id, st)
                                            load()
                                            message = "${o.orderNumber ?: "Commande"} → $st"
                                        } catch (e: Exception) {
                                            message = e.message ?: "Mise à jour impossible"
                                        } finally { busy = false }
                                    }
                                }
                            ) { Text(st.lowercase().replaceFirstChar { it.uppercase() }) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MovementsScreen(mod: Modifier, refresh: Int) {
    var movements by remember { mutableStateOf<List<StockMovement>>(emptyList()) }
    var products by remember { mutableStateOf<List<Product>>(emptyList()) }
    var selectedProduct by remember { mutableStateOf<Product?>(null) }
    var adjustment by remember { mutableStateOf("") }
    var reason by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    fun load() = scope.launch {
        try {
            movements = supabase.from("stock_movements").select().decodeList()
            products = supabase.from("products").select().decodeList<Product>().filter { !it.archived }
        } catch (e: Exception) { message = e.message ?: "Erreur" }
    }
    LaunchedEffect(refresh) { load() }

    Column(mod.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
        Text("Mouvements de stock", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Entrées, sorties et corrections manuelles")
        Spacer(Modifier.height(8.dp))
        ProductPicker(products, selectedProduct) { selectedProduct = it }
        OutlinedTextField(adjustment, { adjustment = it }, Modifier.fillMaxWidth(), label = { Text("Quantité (+ entrée / - sortie)") })
        OutlinedTextField(reason, { reason = it }, Modifier.fillMaxWidth(), label = { Text("Motif") })
        Button({
            val q = num(adjustment)
            val p = selectedProduct
            if (p == null || q == 0.0) { message = "Produit et quantité requis"; return@Button }
            scope.launch {
                try {
                    val newStock = (p.stock + q).coerceAtLeast(0.0)
                    supabase.from("products").update(buildJsonObject { put("stock", newStock) }) { filter { eq("id", p.id) } }
                    supabase.from("stock_movements").insert(buildJsonObject {
                        put("user_id", supabase.auth.currentUserOrNull()?.id)
                        put("product_id", p.id)
                        put("type", if (q > 0) "ENTREE" else "SORTIE")
                        put("quantity", q)
                        put("reason", reason.ifBlank { "Correction manuelle" })
                    })
                    message = "Stock mis à jour"
                    adjustment = ""; reason = ""; selectedProduct = null
                    load()
                } catch (e: Exception) { message = e.message ?: "Erreur" }
            }
        }, Modifier.fillMaxWidth()) { Text("Enregistrer le mouvement") }

        if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(12.dp))
        Text("Derniers mouvements", fontWeight = FontWeight.Bold)
        movements.takeLast(30).reversed().forEach { m ->
            Card(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                Column(Modifier.padding(10.dp)) {
                    Text("${m.type ?: "MOUVEMENT"} • ${m.quantity}")
                    Text(m.reason ?: "")
                }
            }
        }
    }
}

@Composable
fun ReportLine(label: String, value: Double) {
    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(Modifier.padding(14.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label)
            Text(money(value), fontWeight = FontWeight.Bold)
        }
    }
}
