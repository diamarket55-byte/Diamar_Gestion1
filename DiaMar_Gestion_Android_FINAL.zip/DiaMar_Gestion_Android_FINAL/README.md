# DiaMar Gestion — VERSION FINALE

Version native Android moderne de DiaMar Gestion, connectée au projet Supabase DiaMar.

Fonctions V5 :
- Connexion Supabase
- Tableau de bord : CA, résultat, créances, dettes, alertes stock
- Caisse / ventes : produit, quantité, client, paiement, crédit
- Stock : produits, prix, stock minimum, archivage
- Crédits : paiements partiels et règlement
- Achats : fournisseur, facture, cargo, stock et dette fournisseur
- Dépenses
- Clients / fournisseurs
- Rapports
- Actualisation Supabase
- Build APK automatique par GitHub Actions

Le projet utilise uniquement la clé publishable Supabase côté application. La clé secrète Supabase ne doit jamais être mise dans l'application.

## Build cloud
Le fichier `.github/workflows/build-apk.yml` construit automatiquement l'APK debug.
Dans GitHub : Actions > Build DiaMar APK > Run workflow.
L'APK est ensuite disponible comme artifact.

## Important
Cette V5 est une base native fonctionnelle. Pour une version commerciale finale, il faudra encore ajouter :
- impression/PDF de facture
- partage WhatsApp
- gestion complète des paiements dans les tables client_payments/supplier_payments
- historique stock / stock_movements
- recherche et filtres avancés
- catalogue en ligne
- sauvegarde/export
- protection transactionnelle des ventes/achats


## V6 PRO — nouveautés
- Facture PDF partageable depuis la caisse
- Résumé de vente partageable vers WhatsApp / autres applications
- Prix de vente personnalisé par transaction
- Rapport partageable
- Base prête pour l'historique stock et les documents commerciaux

### Prochaine couche commerciale
La prochaine version peut ajouter le catalogue public, recherche avancée, filtres, paiements clients/fournisseurs dans les tables dédiées, mouvements de stock et statistiques par période.


## V7 PRO — gestion commerciale renforcée
- Mouvements de stock manuels : entrée/sortie/correction
- Enregistrement des paiements clients dans `client_payments`
- Colonnes de catalogue public : visibilité, photo, description
- Migration SQL Supabase fournie
- RLS pour les tables de paiements et mouvements
- Préparation du catalogue public

### À exécuter dans Supabase
1. `SUPABASE_V7_MIGRATION.sql`
2. `SUPABASE_CATALOG_V7.sql`

Ces migrations ne suppriment aucune donnée.


## V8 PRO — Catalogue + commandes
- Catalogue public prêt dans le dossier `catalog/`
- Produits publiables avec photo, description et prix
- Bouton de commande WhatsApp
- Commandes enregistrées dans Supabase
- Écran Android Catalogue & commandes
- Migration SQL `SUPABASE_V8_CATALOG_ORDERS.sql`

### Important
Le catalogue public lit uniquement les produits `public_visible=true` et `archived=false`.
La clé utilisée dans la page catalogue est la clé publishable Supabase, jamais une clé secrète.


## V9 PRO — Suivi des commandes
- Cycle de commande : NOUVELLE → CONFIRMEE → PREPAREE → LIVREE
- Possibilité d'ANNULER une commande
- Date de modification automatique `updated_at`
- Index pour recherche par statut/téléphone
- Boutons de changement de statut dans l'application
- Catalogue web avec recherche instantanée


# VERSION FINALE — périmètre

L'application regroupe :
- Connexion Supabase
- Tableau de bord
- Caisse / ventes
- Vente à crédit et paiements partiels
- Stock et mouvements
- Achats et fournisseurs
- Dépenses
- Clients / fournisseurs
- Rapports
- Factures PDF et partage
- Catalogue public
- Commandes WhatsApp
- Suivi des commandes
- Export CSV des produits
- Synchronisation cloud Supabase
- Workflow GitHub Actions pour générer l'APK debug

## Fichiers SQL
1. `SUPABASE_V7_MIGRATION.sql`
2. `SUPABASE_CATALOG_V7.sql`
3. `SUPABASE_V8_CATALOG_ORDERS.sql`
4. `SUPABASE_V9_ORDERS.sql`
5. `SUPABASE_FINAL_MIGRATION.sql`

Exécuter les migrations dans cet ordre dans Supabase SQL Editor si elles n'ont pas déjà été appliquées.

## Génération APK
Le workflow `.github/workflows/build-apk.yml` permet de lancer une compilation Android depuis GitHub Actions et de récupérer l'APK comme artifact.

## Important
La version finale est un candidat de production. Avant une publication Play Store, il faut encore effectuer un test réel sur téléphone et générer une version release signée avec une clé privée conservée hors du code source.
