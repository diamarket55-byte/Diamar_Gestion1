
-- Catalogue public V7 (optionnel, à activer quand le site catalogue sera branché)
ALTER TABLE public.products
  ADD COLUMN IF NOT EXISTS public_visible boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS photo_url text,
  ADD COLUMN IF NOT EXISTS description text;

NOTIFY pgrst, 'reload schema';
