
-- DiaMar Gestion V7 PRO
-- Exécuter une seule fois dans Supabase SQL Editor.

ALTER TABLE public.stock_movements
  ADD COLUMN IF NOT EXISTS type text,
  ADD COLUMN IF NOT EXISTS quantity numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS reason text;

ALTER TABLE public.client_payments
  ADD COLUMN IF NOT EXISTS client_name text,
  ADD COLUMN IF NOT EXISTS amount numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS note text;

ALTER TABLE public.supplier_payments
  ADD COLUMN IF NOT EXISTS supplier_name text,
  ADD COLUMN IF NOT EXISTS amount numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS note text;

ALTER TABLE public.stock_movements ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.client_payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.supplier_payments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "stock_movements_user_policy" ON public.stock_movements;
CREATE POLICY "stock_movements_user_policy" ON public.stock_movements
FOR ALL TO authenticated
USING ((select auth.uid()) = user_id)
WITH CHECK ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "client_payments_user_policy" ON public.client_payments;
CREATE POLICY "client_payments_user_policy" ON public.client_payments
FOR ALL TO authenticated
USING ((select auth.uid()) = user_id)
WITH CHECK ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "supplier_payments_user_policy" ON public.supplier_payments;
CREATE POLICY "supplier_payments_user_policy" ON public.supplier_payments
FOR ALL TO authenticated
USING ((select auth.uid()) = user_id)
WITH CHECK ((select auth.uid()) = user_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.stock_movements TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.client_payments TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.supplier_payments TO authenticated;

NOTIFY pgrst, 'reload schema';
