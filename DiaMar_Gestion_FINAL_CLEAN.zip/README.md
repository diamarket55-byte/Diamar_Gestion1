# DiaMar Gestion FINAL CLEAN

Projet Android natif propre pour DiaMar Gestion.

- Kotlin + Jetpack Compose + Material 3
- Android SDK 36
- Java/JVM 17
- Gradle 8.13
- GitHub Actions

Le workflow construit directement l'APK sans anciennes corrections automatiques.
