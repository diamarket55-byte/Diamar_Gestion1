package com.diamarket.gestion

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class Product(val name: String, val stock: Int, val price: Int)
enum class Screen(val label: String) { HOME("Accueil"), SALE("Vente"), STOCK("Stock"), CREDIT("Crédit"), MORE("Plus") }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { DiaMarApp() } }
    }
}

@Composable
fun DiaMarApp() {
    var screen by remember { mutableStateOf(Screen.HOME) }
    val products = remember {
        listOf(
            Product("Maillot", 0, 6000),
            Product("Débardeur", 0, 7000),
            Product("Caleçon", 0, 7000)
        )
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("DiaMar Gestion") }) },
        bottomBar = {
            NavigationBar {
                Screen.entries.forEach { item ->
                    NavigationBarItem(
                        selected = screen == item,
                        onClick = { screen = item },
                        icon = {},
                        label = { Text(item.label) }
                    )
                }
            }
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(16.dp)
        ) {
            when (screen) {
                Screen.HOME -> HomeScreen(products)
                Screen.SALE -> ListScreen("Nouvelle vente", products)
                Screen.STOCK -> ListScreen("Stock", products)
                Screen.CREDIT -> SimpleScreen("Crédits", "Aucun crédit pour le moment.")
                Screen.MORE -> MoreScreen()
            }
        }
    }
}

@Composable
fun HomeScreen(products: List<Product>) {
    Text("Tableau de bord", style = MaterialTheme.typography.headlineSmall)
    Spacer(Modifier.height(16.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(Modifier.weight(1f)) { Column(Modifier.padding(16.dp)) { Text("Produits"); Text("${products.size}", style = MaterialTheme.typography.headlineMedium) } }
        Card(Modifier.weight(1f)) { Column(Modifier.padding(16.dp)) { Text("Stock"); Text("${products.sumOf { it.stock }}", style = MaterialTheme.typography.headlineMedium) } }
    }
    Spacer(Modifier.height(12.dp))
    SimpleScreen("DiaMar Gestion FINAL", "Projet Android propre. Prêt pour la connexion Supabase et les modules de gestion.")
}

@Composable
fun ListScreen(title: String, products: List<Product>) {
    Text(title, style = MaterialTheme.typography.headlineSmall)
    Spacer(Modifier.height(12.dp))
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(products) { p ->
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column { Text(p.name, style = MaterialTheme.typography.titleMedium); Text("Stock : ${p.stock}") }
                    Text("${p.price} F")
                }
            }
        }
    }
}

@Composable
fun SimpleScreen(title: String, message: String) {
    Text(title, style = MaterialTheme.typography.headlineSmall)
    Spacer(Modifier.height(12.dp))
    Card(Modifier.fillMaxWidth()) { Text(message, Modifier.padding(16.dp)) }
}

@Composable
fun MoreScreen() {
    Text("Plus", style = MaterialTheme.typography.headlineSmall)
    Spacer(Modifier.height(12.dp))
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(listOf("Clients", "Fournisseurs", "Achats", "Dépenses", "Rapports", "Paramètres")) {
            Card(Modifier.fillMaxWidth()) { Text(it, Modifier.padding(16.dp)) }
        }
    }
}
